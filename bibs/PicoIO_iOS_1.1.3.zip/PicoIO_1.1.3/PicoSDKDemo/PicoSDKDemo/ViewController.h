
#import <UIKit/UIKit.h>
#import "PicoSDK.h"

@interface ViewController : UIViewController <CUPicoConnectorDelegate, CUPicoDelegate>

@end
